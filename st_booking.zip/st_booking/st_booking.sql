-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 02, 2023 at 11:07 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `st_booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `bkd_details`
--

DROP TABLE IF EXISTS `bkd_details`;
CREATE TABLE IF NOT EXISTS `bkd_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bk_id` int(11) NOT NULL,
  `bkd_number` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `reason` text COLLATE utf8_unicode_ci NOT NULL,
  `booked_by` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `booked_date` datetime NOT NULL,
  `booked_status` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bkd_details`
--

INSERT INTO `bkd_details` (`id`, `bk_id`, `bkd_number`, `reason`, `booked_by`, `booked_date`, `booked_status`) VALUES
(1, 1, 'S1', 'Submit', 'durga', '2023-02-23 11:10:14', 1),
(3, 2, 'S2', 'Submit', 'yuva', '2023-03-02 06:53:05', 1),
(11, 24, 'S24', 'Booking ', 'durga', '2023-03-02 11:06:07', 1),
(5, 14, 'S14', 'Submit', 'yuva', '2023-03-02 06:53:16', 0),
(6, 3, 'S3', ' travel', 'durga', '2023-03-02 11:04:53', 1),
(7, 4, 'S4', ' ', 'yuva', '2023-03-02 07:05:52', 1),
(8, 10, 'S10', ' ', 'yuva', '2023-03-02 07:09:49', 0),
(9, 5, 'S5', ' cvzfcx', 'yuva', '2023-03-02 07:11:39', 1),
(10, 6, 'S6', ' dff', 'yuva', '2023-03-02 07:12:52', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bkd_details_history`
--

DROP TABLE IF EXISTS `bkd_details_history`;
CREATE TABLE IF NOT EXISTS `bkd_details_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bk_id` int(11) NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `updated_by` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bkd_details_history`
--

INSERT INTO `bkd_details_history` (`id`, `bk_id`, `comments`, `updated_by`, `updated_date`) VALUES
(1, 2, ' ', 'durga', '2023-02-23 11:35:51'),
(2, 3, ' ', 'yuva', '2023-03-02 06:56:36'),
(3, 10, ' dff', 'yuva', '2023-03-02 07:12:52'),
(4, 10, ' ', 'yuva', '2023-03-02 07:13:09'),
(5, 14, ' dvfdzsbzdsvbzfsvbasbv', 'yuva', '2023-03-02 07:13:59'),
(6, 24, 'Booking ', 'durga', '2023-03-02 11:06:07');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(11) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'user',
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `password`, `role`, `created_date`) VALUES
(1, 'Durga', 'durga@gmail.com', 'durga', 'ZHVyZ2E=', 'admin', '2023-02-23 07:11:17'),
(2, 'yuva', 'yuva@gmail.com', 'yuva', 'eXV2YQ==', 'user', '2023-03-02 06:52:18');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
