<?php

namespace App\Controllers;

use App\Models\UserModel;

class Home extends BaseController
{
	public function __construct()
	{
		$session = session();
		if ($session->name == '') {
			return redirect()->to('/');
		}
	}
	public function index()
	{
		helper(['form', 'url']);
		$data['pageTitle'] = 'Login'; //echo $this->request->getVar('LoginBtn1'); exit;
		if (isset($_POST) && $this->request->getVar('LoginBtn1')) {
			$input = $this->validate([
				'username' => 'required',
				'password' => 'required',
			]);
			//	print_r($input); exit;
			$session = session();
			$model = new UserModel();
			if (!$input) {
				$data['validation'] = $this->validator;
			} else {
				$username = $this->request->getVar('username');
				$password = $this->request->getVar('password');

				$data = $model->userCheck($username, $password);

				if ($data) {
					if (base64_decode($data['password']) == $password) {
						$ses_data = [
							'name'       => $data['name'],
							'email'     => $data['email'],
							'username'    => $data['username'],
							'logged_in'     => TRUE
						];
						$session->set($ses_data);
						return redirect()->to('/homepage');
					} else {
						$data['error_message'] = "Invalid Password.";
					}
				} else {
					$data['error_message'] = "Invalid Username.";
				}
			}
		}
		return view('login', $data);
	}

	public function register()
	{
		return view('register');
	}

	public function saveData()
	{
		$data['name'] = $this->request->getVar('name');
		$data['email'] = $this->request->getVar('email');
		$data['username'] = $this->request->getVar('username');
		$data['password'] = base64_encode($this->request->getVar('password'));
		$model = new UserModel();
		$checkDataexsits = $model->getCheckUserExist($data);
		if ($checkDataexsits) {
			$data['msg'] = 'You have already registered with this username / Email. Use different account to login.';
		} else {
			$model->createData($data, 'users');
			$data['msg'] = 'You have registered successfuly. Please login';
		}
		return view('register', $data);
	}

	public function homepage()
	{
		$session = session();
		if ($session->name == '') {
			return redirect()->to('/');
		}
		return view('homepage');
	}

	public function ajax_booking_view()
	{
		$data['id'] = $this->request->getVar('id');
		return view('ajax_view_page', $data);
	}

	public function ajax_booking_add()
	{

		$session = session();
		$model = new UserModel();
		$data['bk_id'] = $this->request->getVar('id');
		$data['bkd_number'] = "S" . $this->request->getVar('id');
		$data['reason'] = $this->request->getVar('reason');
		$data['booked_by'] = $session->username;
		$data['booked_date'] = date('Y-m-d H:i:s');
		$checking = $model->checkId($this->request->getVar('id'));
		if ($checking != "") {

			$data1['reason'] = $this->request->getVar('reason');
			$data1['booked_by'] = $session->username;
			$data1['booked_date'] = date('Y-m-d H:i:s');
			$data1['booked_status'] = 1;
			$model->updateData($data1, 'bkd_details', 'bk_id', $this->request->getVar('id'));
		} else {

			$id = $model->createData($data, 'bkd_details');
		}
		$data2['bk_id'] = $this->request->getVar('id');
		$data2['comments'] = $this->request->getVar('reason');
		$data2['updated_by'] = $session->username;
		$data2['updated_date'] = date('Y-m-d H:i:s');
		$model->createData($data2, 'bkd_details_history');
		echo 1;
	}

	public function ajax_booking_cancel_view()
	{
		$data['id'] = $this->request->getVar('id');
		return view('ajax_view_cancel_page', $data);
	}

	public function ajax_booking_update()
	{
		$session = session();
		$model = new UserModel();
		$id = $this->request->getVar('id');
		$data['bk_id'] = $this->request->getVar('id');
		$data['comments'] = $this->request->getVar('comments');
		$data['updated_by'] = $session->username;
		$data['updated_date'] = date('Y-m-d H:i:s');
		$data1['booked_status'] = 0;
		$model->createData($data, 'bkd_details_history');
		$model->updateData($data1, 'bkd_details', 'bk_id', $id);
		echo 1;
	}

	public function logout()
	{
		$session = session();
		$session->destroy();
		return redirect()->to('/');
	}
	public function bkDetails()
	{
		$uri = new \CodeIgniter\HTTP\URI();
		$uri = current_url(true);
		$getId = $uri->getSegment(3);

		$model = new UserModel();


		$cond = ['bk_id' => $getId];
		$data['history'] = $model->getBkhis('bkd_details_history', $cond);
		return view('booking_history_list', $data);
	}
}
