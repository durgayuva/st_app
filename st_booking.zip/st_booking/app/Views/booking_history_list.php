<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Welcome to Studio Booking</title>
    <meta name="description" content="The small framework with powerful features">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="/favicon.ico">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <!-- STYLES -->
</head>

<body>

    <?php

    if ($history != "") {

    ?>
        <div style="width:80%; margin: 70px;">
            <div class="row">
                <h2>Booking History: </h2>

            </div>
            <table border="1" style="width:100%;">
                <tr style="background:#3b9fd8;color:#F3F3F3;">
                    <th>S.No</th>
                    <th>Booking Id</th>
                    <th>Comments</th>
                    <th>Updated_by</th>
                    <th>Updated_date</th>
                </tr>
                <?php
                $i = 0;
                foreach ($history as $valk) {
                    $i++; ?>
                    <tr>
                        <td><?= $i; ?></td>
                        <td><?= $valk['bk_id']; ?></td>
                        <td><?= $valk['comments']; ?></td>
                        <td><?= $valk['updated_by']; ?></td>
                        <td><?= $valk['updated_date']; ?></td>
                    </tr>

                <?php
                } ?>
            </table>
        </div>
    <?php       } else {
    ?>
        <tr>No Data Founds</tr>
    <?php
    }
    ?>

</body>