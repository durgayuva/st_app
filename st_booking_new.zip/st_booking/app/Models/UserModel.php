<?php

namespace App\Models;

use CodeIgniter\Model;

use Session;

use Config\MyConfig;

// use App\Models\EngineerModel;

class UserModel extends Model
{
	
  public function userCheck($username,$pass){
	  $builder = $this->db->table('users');
	  $builder->select('*');
	  $builder->where('username',$username);
	  $res = $builder->get();
	//  echo $this->db->getLastQuery(); exit;
	  return $res->getRowArray();
  }	
  
  public function getCheckUserExist($objArray){
	  $builder = $this->db->table('users');
	  $builder->select('*');
	  $builder->where('username',$objArray['username']);
	  $builder->orWhere('email',$objArray['email']);
	  $res = $builder->get();
	  return $res->getRowArray();
  }
  
  public function createData($data,$table){
	  $builder = $this->db->table($table);
	  $builder->insert($data);
	  return $this->db->insertID();
  }
  
  public function updateData($data,$table,$field,$val){
	  $builder = $this->db->table($table);
	  $builder->where($field,$val);
	  $builder->update($data);
	  return $val;
  }
  
  public function getRowData($table,$cond){
	  $builder = $this->db->table($table);
	  $builder->select('*');
	  $builder->where($cond);
	  $res = $builder->get();
	//  echo $this->db->getLastQuery(); exit;
	  return $res->getRowArray();
  }
}