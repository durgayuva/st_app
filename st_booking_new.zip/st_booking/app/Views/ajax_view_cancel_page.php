<div>
<form>
	<label>Cancelled Reason</label><br/>
	<textarea name="comments" id="comments" cols="20" rows="4" class="form-control"> </textarea>
	<br/>
	<input type="hidden" id="bk_id" value="<?php echo $id;?>"/>
	<input type="hidden" name="base_url" id="base_url" value="<?php echo base_url();?>"/>
	<button type="button" name="btnBookCancel" id="btnBookCancel" class="btn btn-primary">Submit</button>
</form>
</div>

<script>
	$(document).on("click","#btnBookCancel",function(e){
		var baseurl =$("#base_url").val();
		var reason = $("#comments").text();
		if(reason == ''){
			alert('Please enter the comments');
			return false;
		}
		var id = $('#bk_id').val();
		 $.ajax({
			type:"POST",
			url: baseurl+"ajax_booking_update",
			data:{id:id,'comments':reason},
			success: function(response)
			{ 
				alert('Studio cancelled successfully.');
				window.location.reload();
			}
		 });
	})
</script>