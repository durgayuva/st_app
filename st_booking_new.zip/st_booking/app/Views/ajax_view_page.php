<div>
<form>
	<label>Booked Reason</label><br/>
	<textarea name="reason" id="reason" cols="20" rows="4" class="form-control"> </textarea>
	<br/>
	<input type="hidden" id="bk_id" value="<?php echo $id;?>"/>
	<input type="hidden" name="base_url" id="base_url" value="<?php echo base_url();?>"/>
	<button type="button" name="btnBook" id="btnBook" class="btn btn-primary">Submit</button>
</form>
</div>

<script>
	$(document).on("click","#btnBook",function(e){
		var baseurl =$("#base_url").val();
		var reason = $("#btnBook").text();
		if(reason == ''){
			alert('Please enter the reason');
			return false;
		}
		var id = $('#bk_id').val();
		 $.ajax({
			type:"POST",
			url: baseurl+"ajax_booking_add",
			data:{id:id,'reason':reason},
			success: function(response)
			{ 
				alert('Studio booked successfully.');
				window.location.reload();
			}
		 });
	})
</script>