-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 23, 2023 at 11:40 AM
-- Server version: 8.0.21
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `st_booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `bkd_details`
--

CREATE TABLE `bkd_details` (
  `id` int NOT NULL,
  `bk_id` int NOT NULL,
  `bkd_number` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `reason` text COLLATE utf8_unicode_ci NOT NULL,
  `booked_by` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `booked_date` datetime NOT NULL,
  `booked_status` int NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bkd_details`
--

INSERT INTO `bkd_details` (`id`, `bk_id`, `bkd_number`, `reason`, `booked_by`, `booked_date`, `booked_status`) VALUES
(1, 1, 'S1', 'Submit', 'durga', '2023-02-23 11:10:14', 1),
(2, 2, 'S2', 'Submit', 'durga', '2023-02-23 11:18:04', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bkd_details_history`
--

CREATE TABLE `bkd_details_history` (
  `id` int NOT NULL,
  `bk_id` int NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `updated_by` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bkd_details_history`
--

INSERT INTO `bkd_details_history` (`id`, `bk_id`, `comments`, `updated_by`, `updated_date`) VALUES
(1, 2, ' ', 'durga', '2023-02-23 11:35:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `password`, `created_date`) VALUES
(1, 'Durga', 'durga@gmail.com', 'durga', 'ZHVyZ2E=', '2023-02-23 07:11:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bkd_details`
--
ALTER TABLE `bkd_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bkd_details_history`
--
ALTER TABLE `bkd_details_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bkd_details`
--
ALTER TABLE `bkd_details`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bkd_details_history`
--
ALTER TABLE `bkd_details_history`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
